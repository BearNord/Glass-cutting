#include "GlassItem.h"

GlassItem::GlassItem()
{
    //ctor
}

GlassItem::~GlassItem()
{
    //dtor
}
