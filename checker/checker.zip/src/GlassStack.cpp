#include "GlassStack.h"

GlassStack::GlassStack()
{
    //ctor
    _curItemIdx = 0;
    _nbOfItems = 0;
    _itemIdx = 0;
}

GlassStack::~GlassStack()
{
    //dtor
}
