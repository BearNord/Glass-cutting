What Is This?
-------------

This set of modules is intended to provide working examples of different constraint verification tests,
in order to help developers to quickly understand the code and to provide them a possibility to test 
there Checker code after modification.



How To Use The Examples
-----------------------
Copy Batch_X, Defects_X and Solution_X files in Instances_Checker directory.
Then execute the program. A menu will be shown on console, choose the constraint you want to test.
Automatically, a log_X and statisticsLog_X files will be generated.
Compare recent generated logs with logs in test dirctory to verify Checker functionality.